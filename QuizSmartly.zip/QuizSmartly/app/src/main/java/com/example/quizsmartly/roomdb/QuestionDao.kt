package com.example.quizsmartly.roomdb

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query


@Dao
interface QuestionDao {
    @Insert
    suspend fun insertAll(vararg questions: Question)

    @Query("SELECT * FROM Question WHERE level = :level ORDER BY RANDOM() LIMIT 10")
    suspend fun getQuestionsByLevel(level: String): List<Question>
}


