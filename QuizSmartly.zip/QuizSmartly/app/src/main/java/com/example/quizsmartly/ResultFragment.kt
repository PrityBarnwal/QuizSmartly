package com.example.quizsmartly

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.example.quizsmartly.databinding.FragmentResultBinding

class ResultFragment : Fragment() {

    private val viewModel: QuizViewModel by activityViewModels {
        QuizViewModelFactory((activity?.application as QuizApplication).repository)
    }

    private lateinit var binding: FragmentResultBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentResultBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val score = viewModel.score.value ?: 0
        val totalQuestions = viewModel.totalQuestions.value ?: 10
        binding.tvResult.text = "Your Score: $score/$totalQuestions"

        if (score >= 8) {
            binding.tvPassFail.text = "Congratulations! You passed!"
            binding.btnRetry.visibility = View.GONE
        } else {
            binding.tvPassFail.text = "Sorry, you failed. Try again!"
        }

        binding.btnRetry.setOnClickListener {
            viewModel.retryQuiz()
            findNavController().navigate(R.id.action_resultFragment_to_launchFragment)
        }
    }
}
