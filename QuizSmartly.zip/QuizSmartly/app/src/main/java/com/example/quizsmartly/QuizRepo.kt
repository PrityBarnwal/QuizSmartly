package com.example.quizsmartly

import com.example.quizsmartly.roomdb.Question
import com.example.quizsmartly.roomdb.QuestionDao


class QuestionRepository(private val questionDao: QuestionDao) {

    suspend fun getQuestionsByLevel(level: String) = questionDao.getQuestionsByLevel(level)
    suspend fun insertAll(vararg questions: Question) {
        questionDao.insertAll(*questions)
    }
}


